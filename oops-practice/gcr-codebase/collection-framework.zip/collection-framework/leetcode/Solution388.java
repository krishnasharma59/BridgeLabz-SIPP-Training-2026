import java.util.Stack;

public class Solution388 {
    public int lengthLongestPath(String input) {
        Stack<Integer> stack = new Stack<>();
        stack.push(0); 
        int maxLen = 0;
        for (String s : input.split("\n")) {
            int lev = s.lastIndexOf("\t") + 1; 
            while (lev + 1 < stack.size()) stack.pop(); 
            int len = stack.peek() + s.length() - lev + 1; 
            stack.push(len);
            if (s.contains(".")) maxLen = Math.max(maxLen, len - 1);
        }
        return maxLen;
    }
}